// I won't do this one -- Jani Patrik

const register = async (req, res) => {

};

const login = async (req, res) => {

};

const logout = async (req, res) => {

};

module.exports = {
  logout,
  login,
  register
}